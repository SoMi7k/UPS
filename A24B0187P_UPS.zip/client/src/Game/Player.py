from .Card import Card, Mode, CardRanks, CardSuits, card_mappping

TRUMPH_CARDS = 7 
class Hand: 
    def __init__(self): 
        self.cards = [] 
    
    def check_right_input(self, card_input: str): 
        try: 
            card_mappping(card_input) 
            return False 
        except ValueError: 
            return False
        
    def sort(self, game_mode: Mode):
        """Seřadí karty v ruce podle barvy a hodnoty."""
        suit_order = {
            CardSuits.SRDCE: 0,
            CardSuits.KULE: 1,
            CardSuits.ZALUDY: 2,
            CardSuits.LISTY: 3
        }
        self.cards.sort(key=lambda c: (suit_order[c.suit], c.get_value(game_mode)), reverse=True)
        
    def find_card_in_hand(self, card_input: Card) -> bool: 
        for card in self.cards: 
            if card_input.__eq__(card): 
                return True 
        return False 
        
    def find_card_by_rank(self, rank: CardRanks, mode: Mode) -> bool: 
        for card in self.cards: 
            if card.get_value(mode) == rank.value: 
                return True 
        return False 
        
    def find_card_by_suit(self, suit: CardSuits) -> bool: 
        for card in self.cards: 
            if card.suit == suit: 
             return True 
        return False 
    
    def get_hand(self, mode: Mode):
        return self.sort(mode)
    
    def remove_card(self, card_to_remove: Card) -> None: 
        self.cards.remove(card_to_remove) 
        
    def add_card(self, card_to_add: Card) -> None: 
        self.cards.append(card_to_add)
                
    def remove_hand(self):
        self.cards = []
             
class Player: 
    def __init__(self, number: int, nickname: str, hand: Hand|None): 
        self.number = number
        self.nickname = nickname
        self.hand: Hand|None = hand
        self.status = 1
        
    def remove_hand(self):
        self.hand.remove_hand()
    
    def add_card(self, card: Card): 
        """Adds card to player from deck."""
        if self.hand:
            self.hand.add_card(card) 
        
    def has_card_in_hand(self) -> bool: 
        """Zkontroluje jestli má hráč ještě čím hrát."""
        if self.hand:
            return True if self.hand.cards else False 
        else:
            return False
    
    def has_won(self): 
        """Vyhrál hráč štych?""" 
        return True if self.hand else False 
    
    def choose_card(self) -> Card: 
        """Allows the player to select and play a card with full validation.""" 
        # Inicializace proměnné played_card = None # Opakování smyčky, dokud není platná karta v ruce 
        while True: 
            played_card_input = input("Kterou kartu chcete zahrát?\n> ") 
            try: # Pokusí se namapovat vstup na objekt karty 
                played_card = card_mappping(played_card_input) 
                # Zkontroluje, zda je karta v ruce 
                if self.hand and self.hand.find_card_in_hand(played_card): 
                    print(f"Zahrál si {played_card}") 
                    break 
                # Pokud je vše v pořádku, ukončí se smyčka 
                else: print("Karta není ve tvém balíčku karet! Zkus to znovu.") 
            except ValueError: # Pokud dojde k chybě při mapování (neplatný formát), 
                # vytiskne se chybová zpráva 
                print("Zadal jsi špatný kód karty! Zkus to znovu.") 
        return played_card 
    
    def pick_cards(self, count: int):
        """Returns a specific amount of cards."""
        cards = []
        if self.hand:
            if count == "all":
                count = len(self.hand.cards)
            for i in range(count):
                if i > len(self.hand.cards):
                    break
                cards.append(self.hand.cards[i])
            return cards
        else:
            print("⚠ Hand is not inicialized!")
            return cards
    
    def sort_hand(self, mode=Mode.BETL):
        """Seřadí karty v ruce podle barvy a hodnoty."""
        self.hand.sort(mode)
            
    def __str__(self):
        return f"{self.nickname} ({self.number}): {', '.join(str(card) for card in self.hand.cards)}"