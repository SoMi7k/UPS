from src.Gui import Gui

if __name__ == "__main__":
    gui = Gui()
    gui.run()